package com.example.practical4_table141

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var text=findViewById<EditText>(R.id.mytext)
        var btn=findViewById<Button>(R.id.login)
        btn.setOnClickListener{
            var strMessage:String
            strMessage=text.getText().toString()
            Toast.makeText(this,"hello  $strMessage",Toast.LENGTH_LONG).show()
        }
    }
}
